from clean_folder.clean import main
from clean_folder.file_generator import main_generator


__ALL__ = ['main', 'main_generator']